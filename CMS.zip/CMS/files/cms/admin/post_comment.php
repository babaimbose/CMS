<?php include "includes/admin_header.php" ?>

    <div id="wrapper">

<?php include "includes/admin_navigation.php" ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">

                        <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>


<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Comment ID</th>
            <th>Comment Post ID</th>
            <th>Comment Author</th>
            <th>Comment Email</th>
            <th>Comment Content</th>
            <th>Comment Status</th>
            <th>Comment Date</th>
            <th>In Response to</th>
            <th>Approve</th>
            <th>Unapprove</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        post_comments();
        ?>
    </tbody>
</table>
<?php
    if(isset($_GET['delete_comment_post'])){
    delete_post_comments();
    }

    if(isset($_GET['approve'])){
    approve_comments();
    }

    if(isset($_GET['unapprove'])){
    unapprove_comments();
    }
?>


                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include "includes/admin_footer.php" ?>


