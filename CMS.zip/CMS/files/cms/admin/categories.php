<?php include "includes/admin_header.php" ?>

    <div id="wrapper">

<?php include "includes/admin_navigation.php" ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">

                        <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>

                        <div class="col-xs-6">

                            <?php 
                            // Inserting values inside the categories table
                            insert_categories();
                            ?>


                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="cat_title">Add Category</label>
                                    <input class="form-control" type="text" name="cat_title">  
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="submit" value="Add Category">
                                </div>
                            </form>




                            <form action="" method="post">


                                <?php // Getting the categories in the form for update
                                    if(isset($_GET['edit'])){
                                    $update_cat_id = $_GET['edit'];
                                    $query = "SELECT * FROM categories WHERE cat_id = $update_cat_id";
                                    $select_categories_id = mysqli_query($connection, $query);

                                    while($row = mysqli_fetch_assoc($select_categories_id)){
                                        $cat_id = $row['cat_id'];
                                        $cat_title = $row['cat_title'];
                                        $del_id = $row['cat_id'];
                                        $edit_id = $row['cat_id'];
                                        }
                                    ?>


                                <div class="form-group">
                                    <label for="cat_title">Edit Category</label>
                                    <input value="<?php if(isset($cat_title)) echo $cat_title; ?>" class="form-control" type="text" name="updated_cat_title">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="update_catetory" value="Update Category">
                                </div>
                                <?php
                                }
                                ?>




                                <?php // Updating categroies table
                                    if(isset($_POST["update_catetory"])){
                                    $update_category = $_POST["updated_cat_title"];
                                    $updated_query = "UPDATE categories SET cat_title = '$update_category' WHERE cat_id = $cat_id";
                                    $update_category_query = mysqli_query($connection, $updated_query);
                                }
                                ?>

                            </form>
                        </div>






                        <div class="col-xs-6">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Category Title</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>




                                <?php //Find all categories query
                                finding_categories();
                                ?>





                                <?php //Deleting the categories
                                deleting_categories();
                                ?>





                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include "includes/admin_footer.php" ?>

