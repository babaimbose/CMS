<?php include "includes/admin_header.php" ?>

    <div id="wrapper">

<?php include "includes/admin_navigation.php" ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to Admin
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                    </div>
                </div>
                <!-- /.row -->


                <!-- /.row -->


                
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                  <div class='huge'><?php show_summary_data('posts'); ?></div>
                        <div>Posts</div>
                    </div>
                </div>
            </div>
            <a href="admin_posts.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                     <div class='huge'><?php show_summary_data('comments');?></div>
                      <div>Comments</div>
                    </div>
                </div>
            </div>
            <a href="admin_comments.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-user fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                    <div class='huge'><?php show_summary_data('users'); ?></div>
                        <div> Users</div>
                    </div>
                </div>
            </div>
            <a href="admin_users.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-list fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class='huge'><?php show_summary_data('categories'); ?></div>
                         <div>Categories</div>
                    </div>
                </div>
            </div>
            <a href="categories.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
                <!-- /.row -->

<div id="columnchart_material" style="width: auto; height: 500px;"></div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Data', 'Count'],

          <?php
        $total_posts_query = "SELECT * FROM posts";
        $connection_total_posts_query = mysqli_query($connection, $total_posts_query);
        $total_post = mysqli_num_rows($connection_total_posts_query);
        confirmQuery($total_post);

        $total_draft_posts_query = "SELECT * FROM posts WHERE post_status = 'draft' ";
        $connection_total_draft_posts_query = mysqli_query($connection, $total_draft_posts_query);
        $total_draft_post = mysqli_num_rows($connection_total_draft_posts_query); 
        confirmQuery($total_draft_post);

        $total_comments_query = "SELECT * FROM comments";
        $connection_total_comments_query = mysqli_query($connection, $total_comments_query);
        $total_comments = mysqli_num_rows($connection_total_comments_query);
        confirmQuery($total_comments);       

        $total_unapproved_comments_query = "SELECT * FROM comments WHERE comment_status = 'Unapproved' ";
        $connection_total_unapproved_comments_query = mysqli_query($connection, $total_unapproved_comments_query);
        $total_unapproved_comments = mysqli_num_rows($connection_total_unapproved_comments_query);
        confirmQuery($total_unapproved_comments); 

        $total_users_query = "SELECT * FROM users";
        $connection_total_users_query = mysqli_query($connection, $total_users_query);
        $total_users = mysqli_num_rows($connection_total_users_query);
        confirmQuery($total_users); 

        $total_subscribers_query = "SELECT * FROM users WHERE user_role = 'Subscriber' ";
        $connection_total_subscribers_query = mysqli_query($connection, $total_subscribers_query);
        $total_subscribers = mysqli_num_rows($connection_total_subscribers_query);
        confirmQuery($total_subscribers); 

        $toatl_categories_query = "SELECT * FROM categories";
        $connection_toatl_categories_query = mysqli_query($connection, $toatl_categories_query);
        $total_categories = mysqli_num_rows($connection_toatl_categories_query);
        confirmQuery($total_categories); 


          $elements = ["Published Posts", "Draft Posts", "Approved Comments", "Unapproved Comments", "Total Users", "Total Subscribers", "Categories"];
          $element_count = [$total_post, $total_draft_post, $total_comments, $total_unapproved_comments, $total_users, $total_subscribers, $total_categories];

          for($i=0; $i<7; $i++){
            echo "['{$elements[$i]}'".","."{$element_count[$i]}],";
          }
          ?>

          //['2014', 1000],
        ]);

        var options = {
          chart: {
            title: '',
            subtitle: '',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>

<?php include "includes/admin_footer.php" ?>

