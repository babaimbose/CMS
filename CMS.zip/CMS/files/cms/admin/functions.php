<?php

function insert_categories(){
	// Inserting values inside the categories table

	global $connection;

    if(isset($_POST['submit'])){
        $cat_title = $_POST['cat_title'];

        if($cat_title == "" || empty($cat_title)){
            echo "The field should not be empty";
        }else{
            $query_fill_cat = "INSERT INTO categories(cat_title) VALUES('$cat_title')";
            $create_category_query = mysqli_query($connection, $query_fill_cat);
        
        if(!$create_category_query){
            die("QUERY FAILED" . mysqli_error($connection));
        }

        }
    }
}

?>

<?php
function getting_categories(){

	// Getting the categories in the form for update
	global $connection;

	    if(isset($_GET['edit'])){
	        $update_cat_id = $_GET['edit'];
	    	$query = "SELECT * FROM categories WHERE cat_id = $update_cat_id";
	    	$select_categories_id = mysqli_query($connection, $query);

		    while($row = mysqli_fetch_assoc($select_categories_id)){
		        $cat_id = $row['cat_id'];
		        $cat_title = $row['cat_title'];
		        $del_id = $row['cat_id'];
		        $edit_id = $row['cat_id'];
	    }
	}

}

?>

<?php

function finding_categories(){
//Find all categories query
	global $connection;

    $query = "SELECT * FROM categories";
    $select_all_categories_query = mysqli_query($connection, $query);

    while($row = mysqli_fetch_assoc($select_all_categories_query)){
        $cat_id = $row['cat_id'];
        $cat_title = $row['cat_title'];
        $del_id = $row['cat_id'];
        $edit_id = $row['cat_id'];
?>
        <tr>
            <td><?php echo $cat_id; ?></td>
            <td><?php echo $cat_title; ?></td>
            <td><a href="categories.php?edit=<?php echo $edit_id; ?>">Edit</a></td>
            <td><a href="categories.php?delete=<?php echo $del_id; ?>">Delete</a></td>
        </tr>
<?php
    }
}

?>

<?php

function deleting_categories(){
	//Deleting the categories
	global $connection;

if(isset($_GET["delete"])){
    $del_the_id = $_GET["delete"];
    $del_query = "DELETE FROM categories WHERE cat_id = $del_the_id";

    $final_del_query = mysqli_query($connection, $del_query);
    header("Location:categories.php");
}
}

?>

<?php

function filling_post_table(){
    global $connection;
    $fill_post_table_query = "SELECT * FROM posts ORDER BY post_id DESC";
    $fill_post_table = mysqli_query($connection, $fill_post_table_query);

    while($post_database = mysqli_fetch_assoc($fill_post_table)){
        $post_id = $post_database['post_id'];
        $post_category_id = $post_database['post_category_id'];
        $post_title = $post_database['post_title'];
        $post_author = $post_database['post_author'];
        $post_user = $post_database['post_user'];
        $post_date = $post_database['post_date'];
        $post_image = $post_database['post_image'];
        $post_content = $post_database['post_content'];
        $post_tags = $post_database['post_tags'];
        $post_comment_count = $post_database['post_comment_count'];
        $post_status = $post_database['post_status'];
        $post_views_count = $post_database['post_views_count'];
?>
    <tr>
        <td><input type="checkbox" name="checkBoxArray[]" class="checkBoxes" value="<?php echo $post_id; ?>"></td>
        <td><?php echo $post_id ?></td>
<?php
        $query = "SELECT * FROM categories WHERE cat_id = $post_category_id";
        $show_category = mysqli_query($connection, $query);
        while($row = mysqli_fetch_assoc($show_category)){

            $cat_title = $row['cat_title'];

            echo "<td>$cat_title</td>";  
            }   
?>
        <td><?php echo $post_title ?></td>
        <td><?php echo $post_author ?></td>
        <!--<td><?php echo $post_user ?></td>-->
        <td><?php echo $post_date ?></td>
        <td><?php echo "<img width='100px' src=../images/{$post_image} >" ?></td>
        <!--<th><?php //echo $post_content ?></th>-->
        <td><?php echo $post_tags ?></td>
        <?php
         $query = "SELECT * FROM comments WHERE comment_post_id = $post_id";
        $comment_count = mysqli_query($connection, $query);
        $real_count = mysqli_num_rows($comment_count);
        ?>
        <td><a href='post_comment.php?id=<?php echo $post_id ?>'><?php echo $real_count ?></a></td>
        <td><?php echo $post_status ?></td>
        <td><?php echo $post_views_count ?></td>
        <td><?php echo "<a href='admin_posts.php?reset_views=$post_id'>Reset</a>"?></td>
        <td><a href='<?php echo "/cms/post.php?p_id=$post_id"?>'>View</a></td>
        <td><a href="<?php echo 'admin_posts.php?source=edit_post&p_id='. $post_id ?>">Edit</a></td>
        <td><a href="<?php echo 'admin_posts.php?delete='. $post_id ?>" onclick=" return confirm('Are you sure that you want to delete?');">Delete</a></td>
    </tr>



<?php
    }

    if(isset($_GET['delete'])){
        $delete_post = $_GET['delete'];
        $delete_post_query = "DELETE FROM posts WHERE post_id = $delete_post";
        $final_del_query = mysqli_query($connection, $delete_post_query);
        header("location:admin_posts.php");
        //die("QUERY FAILED ". mysqli_error($connection));
    }

    if(isset($_GET['reset_views'])){
        $reset_post_view_id = $_GET['reset_views'];
        $query_reset_views = "SELECT * FROM posts WHERE post_id = $reset_post_view_id";
        $connection_reset_views = mysqli_query($connection, $query_reset_views);
        confirmQuery($connection_reset_views);
        while($result = mysqli_fetch_assoc($connection_reset_views)){
            $post_id = $result['post_id'];
            $post_views_count = $result['post_views_count'];
        }

        $query_update_reset_views = "UPDATE posts SET post_views_count = 0 WHERE post_id = $post_id";
        $connection_update_reset_views = mysqli_query($connection, $query_update_reset_views);
        header("location:admin_posts.php");
        confirmQuery($connection_update_reset_views);

    }

}
?>

<?php
    function insert_post_into_database(){

        global $connection;

        if(isset($_POST['create_post'])){
            $post_title = mysqli_real_escape_string($connection, trim($_POST['title']));
            $post_category_id = mysqli_real_escape_string($connection, trim($_POST['post_category']));
            $post_author = mysqli_real_escape_string($connection, trim($_POST['post_author']));
            $post_status = mysqli_real_escape_string($connection, trim($_POST['post_status']));

            $post_image = $_FILES['image']['name'];
            $post_image_temp = $_FILES['image']['tmp_name'];

            $post_tags = mysqli_real_escape_string($connection, trim($_POST['post_tags']));
            $post_content = mysqli_real_escape_string($connection, trim($_POST['post_content']));
            $post_date = mysqli_real_escape_string($connection, trim(date("d-m-y h:i:sa")));
            //$post_comment_count = 4;

            move_uploaded_file($post_image_temp, "../images/$post_image");

        //$post_query = "INSERT INTO posts(post_title, post_category_id, post_author, post_status, post_image, post_tags, post_content, post_date) VALUES('$post_title', $post_category_id, '$post_author', '$post_status', '$post_image', '$post_tags', '$post_content', '$post_date' )";

        $post_query = mysqli_prepare($connection, "INSERT INTO posts(post_title, post_category_id, post_author, post_status, post_image, post_tags, post_content, post_date) VALUES(?,?,?,?,?,?,?,?)");

        mysqli_stmt_bind_param($post_query, "sissssss", $post_title, $post_category_id, $post_author, $post_status, $post_image, $post_tags, $post_content, $post_date);

        mysqli_stmt_execute($post_query);

        //$post_send_query = mysqli_query($connection, $post_query);

        echo "Post created successfully!";

        if(!$post_query){
            die("QUERY FAILED ". mysqli_error($connection));
        }

        mysqli_stmt_close($post_query);

        }

    }
?>

<?php
    function confirmQuery($result){
        global $connection;
        if(!$result){
           die("Query Failed ". mysqli_error($connection)); 
        }
    }
?>


<?php
    function submit_comment(){
        global $connection;
            if(isset($_POST['submit_comment'])){
            $the_post_id = $_GET['p_id'];
            $comment_post_id = $the_post_id;
            $comment_author = $_POST['comment_author'];
            $comment_email = $_POST['comment_email'];
            $comment_content = $_POST['comment_content'];
            $date = date("Y-m-d h:i:sa");

            $query_submit_comment = "INSERT INTO comments(comment_post_id, comment_author, comment_email, comment_status, comment_content, comment_date ) VALUES ($comment_post_id, '{$comment_author}', '{$comment_email}', 'Unapproved', '{$comment_content}', '{$date}') ";

            $query_submit_comment_connection = mysqli_query($connection, $query_submit_comment);

        }

            $query_select_comments = "SELECT * FROM comments WHERE comment_post_id = $the_post_id";
            $connection_select_comments = mysqli_query($connection, $query_select_comments);
            $total_comments = mysqli_num_rows($connection_select_comments);
            confirmQuery($total_comments);

            //counting comments on each post
            //$query_comment_count = "UPDATE posts SET post_comment_count =  post_comment_count + 1 WHERE post_id = $the_post_id ";
            $query_comment_count = "UPDATE posts SET post_comment_count = $total_comments WHERE post_id = $the_post_id";
            $connection_comment_count = mysqli_query($connection, $query_comment_count);
            confirmQuery($connection_comment_count);
    }
?>

<?php
    function show_comment_table(){
        global $connection;
        $query_select_comment = "SELECT * FROM comments ORDER BY comment_id DESC";
        $query_show_comment_connection = mysqli_query($connection, $query_select_comment);

                while($row = mysqli_fetch_assoc($query_show_comment_connection)){
                $show_comment_id = $row['comment_id'];
                $show_comment_post_id = $row['comment_post_id'];
                $show_comment_author = $row['comment_author'];
                $show_comment_email = $row['comment_email'];
                $show_comment_status = $row['comment_status'];
                $show_comment_content = $row['comment_content'];
                $show_comment_date = $row['comment_date'];

                echo"<tr>";
                echo "<td>$show_comment_id</td>";
                echo "<td>$show_comment_post_id</td>";
                echo "<td>$show_comment_author</td>";
                echo "<td>$show_comment_email</td>";
                echo "<td>$show_comment_content</td>";
                echo "<td>$show_comment_status</td>";
                echo "<td>$show_comment_date</td>";

                $query_fetch_post_title = "SELECT * FROM posts WHERE post_id = $show_comment_post_id";
                $connection_post_title = mysqli_query($connection, $query_fetch_post_title);

                while($result = mysqli_fetch_assoc($connection_post_title)){
                    $post_id = $result['post_id'];
                    $post_title = $result['post_title'];
                    echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
                }
                
                echo "<td><a href='admin_comments.php?approve=$show_comment_id'>Approve</a></td>";
                echo "<td><a href='admin_comments.php?unapprove=$show_comment_id'>Unapprove</a></td>";
                echo "<td><a onclick=\"javascript: return confirm('Are you sure you want to delete?') \" href='admin_comments.php?delete=$show_comment_id'>Delete</a></td>";
                echo"</tr>";
            }
    }
?>


<?php
    function delete_comments(){
        global $connection;
        if(isset($_GET['delete'])){
            $delete_comment_id = $_GET['delete'];

            $query_delete_comment = "DELETE FROM comments WHERE comment_id = $delete_comment_id";
            $connection_delete_comment = mysqli_query($connection, $query_delete_comment);
            header("location:admin_comments.php");
            confirmQuery($connection_delete_comment);
        }
    }

?>

<?php
    function delete_user(){
        global $connection;
        if($_SESSION['user_role'] == "Admin"){
                    if(isset($_GET['delete_user'])){
                    $delete_user_id = mysqli_real_escape_string($_GET['delete_user']);
                    $query_delete_user = "DELETE FROM users WHERE user_id = $delete_user_id";
                    $connection_delete_user = mysqli_query($connection, $query_delete_user);
                    header("location:admin_users.php");
                    confirmQuery($connection_delete_user);
                }
        }
    }

?>

<?php
    function exert_category_page(){
        global $connection;
        if(isset($_GET['category'])){
            $post_caategory_id = $_GET['category'];
        $query = "SELECT * FROM posts WHERE post_category_id = $post_caategory_id";
        $select_all_from_posts = mysqli_query($connection, $query);

            while($row = mysqli_fetch_assoc($select_all_from_posts)){
                $post_id = $row["post_id"];
                $post_title = $row["post_title"];
                $post_author = $row["post_author"];
                $post_date = $row["post_date"];
                $post_image = $row["post_image"];
                $post_status = $row['post_status'];
                $post_content = substr($row["post_content"],0,250);

                if($post_status == 'published' || $post_status == ''){
?>
                <h2>
                    <a href='post.php?p_id=<?php echo $post_id?>'><?php echo $post_title; ?></a>
                </h2>
                <p class='lead'>
                    by <a href='index.php'><?php echo $post_author; ?></a>
                </p>
                <p><span class='glyphicon glyphicon-time'></span><?php echo 'Posted on: ' . $post_date ?></p>
                <hr>
                <img class='img-responsive' src='images/<?php echo $post_image; ?>' alt=''>
                <hr>
                <p><?php echo $post_content; ?></p>
                <a class='btn btn-primary' href=''>Read More <span class='glyphicon glyphicon-chevron-right'></span></a>

                <hr>;

<?php           }   
?>

<?php            
            }
        }
    }
?>

<?php
    function sidebar_category(){
        global $connection;
        $query = "SELECT * FROM categories";
        $select_all_categories_query = mysqli_query($connection, $query);

        while($row = mysqli_fetch_assoc($select_all_categories_query)){
            $cat_title = $row['cat_title'];
            $cat_id = $row['cat_id'];
            echo "<li><a href='category.php?category=$cat_id'>$cat_title</a></li>";
        }
    }

?>

<?php

function approve_comments(){
    global $connection;
    if(isset($_GET['approve'])){
    $approve_comment_id = $_GET['approve'];
    $query_approve_comment = "UPDATE comments SET comment_status = 'Approved' WHERE comment_id = $approve_comment_id";
    $connection_approve_comment = mysqli_query($connection, $query_approve_comment);
    header("location:admin_comments.php");
    confirmQuery($connection_approve_comment);
    }
}
?>

<?php

function unapprove_comments(){
    global $connection;
    if(isset($_GET['unapprove'])){
    $unapprove_comment_id = $_GET['unapprove'];
    $query_unapprove_comment = "UPDATE comments SET comment_status = 'Unapproved' WHERE comment_id = $unapprove_comment_id";
    $connection_unapprove_comment = mysqli_query($connection, $query_unapprove_comment);
    header("location:admin_comments.php");
    confirmQuery($connection_unapprove_comment);
    }
}
?>


<?php
    function show_users_table(){
        global $connection;
        $query_select_user = "SELECT * FROM users ORDER BY user_id DESC";
        $query_show_user_connection = mysqli_query($connection, $query_select_user);

                while($row = mysqli_fetch_assoc($query_show_user_connection)){
                $show_user_id = $row['user_id'];
                $show_username = $row['username'];
                $show_firstname = $row['user_firstname'];
                $show_lastname = $row['user_lastname'];
                $show_user_email = $row['user_email'];
                $show_user_role = $row['user_role'];
                $show_user_date = $row['user_date'];

                echo"<tr>";
                echo "<td>$show_user_id</td>";
                echo "<td>$show_username</td>";
                echo "<td>$show_firstname</td>";
                echo "<td>$show_lastname</td>";
                echo "<td>$show_user_email</td>";
                echo "<td>$show_user_role</td>";
                echo "<td>$show_user_date</td>";

/*                $query_fetch_post_title = "SELECT * FROM posts WHERE post_id = $show_comment_post_id";
                $connection_post_title = mysqli_query($connection, $query_fetch_post_title);

                while($result = mysqli_fetch_assoc($connection_post_title)){
                    $post_id = $result['post_id'];
                    $post_title = $result['post_title'];
                    echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
                }*/
                
                echo "<td><a href='admin_users.php?change_role_to_admin=$show_user_id'>Admin</a></td>";
                echo "<td><a href='admin_users.php?change_role_to_subscriber=$show_user_id'>Subscriber</a></td>";
                echo "<td><a href='admin_users.php?source=edit_user&user_id=$show_user_id'>Edit</a></td>";
                echo "<td><a href='admin_users.php?delete_user=$show_user_id'>Delete</a></td>";
                echo"</tr>";
            }
    }
?>

<?php
    function change_role_to_admin(){
        global $connection;
        if(isset($_GET['change_role_to_admin'])){
            $change_user_id = $_GET['change_role_to_admin'];
            $query_change_role = "UPDATE users SET user_role = 'Admin' WHERE user_id = $change_user_id";
            $connection_change_role = mysqli_query($connection, $query_change_role);
            header("location:admin_users.php");
            confirmQuery($connection_change_role);
        }
    }

?>

<?php
    function change_role_to_subscriber(){
        global $connection;
        if(isset($_GET['change_role_to_subscriber'])){
            $change_user_id = $_GET['change_role_to_subscriber'];
            $query_change_role = "UPDATE users SET user_role = 'Subscriber' WHERE user_id = $change_user_id";
            $connection_change_role = mysqli_query($connection, $query_change_role);
            header("location:admin_users.php");
            confirmQuery($connection_change_role);
        }
    }

?>

 <?php
    function insert_user_into_database(){

        global $connection;

        if(isset($_POST['create_user'])){
            $username = $_POST['username'];
            $user_password = $_POST['user_password'];
            $user_firstname = $_POST['user_firstname'];
            $user_lastname = $_POST['user_lastname'];

            $user_password = password_hash($user_password, PASSWORD_BCRYPT, array("cost"=>12));

/*            $user_image = $_FILES['image']['name'];
            $user_image_temp = $_FILES['image']['tmp_name'];*/

            $user_email = $_POST['user_email'];
            $user_role = $_POST['user_role'];
            $user_date = date("d-m-y h:i:sa");
            //$post_comment_count = 4;

           // move_uploaded_file($post_image_temp, "../images/$post_image");

        $user_query = "INSERT INTO users (username, user_password, user_firstname, user_lastname, user_email, user_role, user_date) VALUES('$username', '$user_password', '$user_firstname', '$user_lastname', '$user_email', '$user_role', '$user_date')";

        $user_send_query = mysqli_query($connection, $user_query);

        echo "User Created: "." ". "<a href='admin_users.php'>View Users</a>";

        if(!$user_send_query){
            die("QUERY FAILED ". mysqli_error($connection));
        }

        }

    }
?>

<?php
/*    function fetch_edit_user_data(){
        global $connection;
        if(isset($_GET['user_id'])){
            $edit_user_id = $_GET['user_id'];
            $query_fetch_edit_user_data = "SELECT * FROM users WHERE user_id = $edit_user_id";
            $connection_fetch_edit_user_data = mysqli_query($connection, $query_fetch_edit_user_data);
            confirmQuery($connection);
            }
            while($result = mysqli_fetch_assoc($connection_fetch_edit_user_data)){
                $user_firstname = $result['user_firstname'];
                $user_lastname = $result['user_lastname'];
                $user_username = $result['username'];
                $user_email = $result['user_email'];
                $user_password = $result['user_password'];
                $user_role = $result['user_role'];
        }
    }*/
?>

<?php
    function update_user_data(){
        global $connection;
        $edit_user_id = $_GET['user_id'];
        if(isset($_POST['update_user'])){
            $user_firstname = $_POST['user_firstname'];
            $user_lastname = $_POST['user_lastname'];
            $updated_user_role = $_POST['user_role'];
            $user_email = $_POST['user_email'];
            $user_username = $_POST['username'];
            $updated_user_password = $_POST['user_password'];

            $enrypted_password = password_hash($updated_user_password, PASSWORD_BCRYPT, array("cost"=>12));


        $query_update_user_data = "UPDATE users SET user_firstname = '$user_firstname', user_lastname = '$user_lastname', user_role = '$updated_user_role', user_email = '$user_email', username = '$user_username', user_password = '$enrypted_password' WHERE user_id = $edit_user_id ";

        $connection_update_user_data = mysqli_query($connection, $query_update_user_data);

        //header("location:admin_users.php?source=edit_user&user_id=$edit_user_id ");
    }
}
?>

<?php
    function submit_login(){
        global $connection;
        if(isset($_POST['login'])){
           $username = mysqli_real_escape_string($connection, $_POST['username']);
           $password = mysqli_real_escape_string($connection, $_POST['password']);

           $query_user_login = "SELECT * FROM users WHERE username = '$username'";
           $connection_user_login = mysqli_query($connection, $query_user_login);

           while($row = mysqli_fetch_assoc($connection_user_login)){
                $user_id = $row['user_id'];
                $user_username = $row['username'];
                $user_password = $row['user_password'];
                $user_email = $row['user_email'];
                $user_firstname = $row['user_firstname'];
                $user_lastname = $row['user_lastname'];
                $user_role = $row['user_role'];
           }

           if($username == $user_username && password_verify($password, $user_password) && $user_role == "Admin"){
                $_SESSION['firstname'] = $user_firstname;
                $_SESSION['lastname'] = $user_lastname;
                $_SESSION['user_role'] = $user_role;
                $_SESSION['user_email'] = $user_email;
                $_SESSION['username'] = $user_username;

                header("location:admin");
           }else{
                header("location:login.php");
           }
        }
    }

?>

<?php
    function update_profile(){
        global $connection;
        if(isset($_POST['update_profile'])){
            $user_id = $_SESSION['username'];
            $user_firstname = $_POST['user_firstname'];
            $user_lastname = $_POST['user_lastname'];
            $user_role = $_POST['user_role'];
            $user_email = $_POST['user_email'];
            //$user_username = $_POST['username'];
            $user_password = $_POST['user_password']; 
            
            $query_update_profile = "UPDATE users SET user_firstname = '$user_firstname', user_lastname = '$user_lastname', user_role = '$user_role', user_email = '$user_email', user_password = '$user_password' WHERE username = '$user_id'";
            $connection_update_profile = mysqli_query($connection, $query_update_profile);       
        }
    }

?>

<?php
    function show_summary_data($table){
        global $connection;
        $query = "SELECT * FROM $table";
        $connection_query = mysqli_query($connection, $query);
        confirmQuery($connection_query);
        $result = mysqli_num_rows($connection_query);
        echo $result;
    }
?>

<?php

    function show_online_users(){
        global $connection;
        $session_id = session_id();
        $time = time();
        $buffer_time_allowed = 10;
        $time_out = $time - $buffer_time_allowed;

        $query_select_all_users_online = "SELECT * FROM users_online";
        $connection_users_online = mysqli_query($connection, $query_select_all_users_online);
        confirmQuery($connection_users_online);
        $users_online_count = mysqli_num_rows($connection_users_online);

        if($users_online_count == NULL){
            $query_insert_users_online_data = "INSERT INTO users_online (session, time) VALUES ('$session_id', '$time')";
            $connection_insert_users_online_data = mysqli_query($connection, $query_insert_users_online_data);
            confirmQuery($connection_insert_users_online_data);
        }else{
            $query_update_users_online_data = "UPDATE users_online SET time = '$time_out' WHERE session = '$session_id'";
            $connection_update_users_online_data = mysqli_query($connection, $query_update_users_online_data);
            confirmQuery($connection_update_users_online_data);
        }

        $query_count_online_users = "SELECT * FROM users_online WHERE time > '$time_out'";
        $connection_count_online_users = mysqli_query($connection, $query_count_online_users);
        confirmQuery($connection_count_online_users);
        $online_users_count = mysqli_num_rows($connection_count_online_users);
        echo "Online-Users : {$online_users_count}";
    }

?>

<?php
    function get_comments(){
        global $connection;
        if(isset($_GET['id'])){
            $the_post_id = $_GET['id'];
            $query = "SELECT * FROM comments WHERE comment_post_id = $the_post_id";
            $connection_query = mysqli_query($connection, $query);
            while($result = mysqli_fetch_assoc($connection_query)){
                $comment_id = $result['comment_id'];
            }
            echo "<td><a href='comment.php?id=$post_id'>$post_comment_count</a></td>";
        }
    }

?>

<?php
    function post_comments(){
        global $connection;
        if(isset($_GET['id'])){
            $the_post_id = $_GET['id'];
            $query_post_comments = "SELECT * FROM comments WHERE comment_post_id = $the_post_id";
            $connection_post_comments = mysqli_query($connection, $query_post_comments);

                while($row = mysqli_fetch_assoc($connection_post_comments)){
                $show_comment_id = $row['comment_id'];
                $show_comment_post_id = $row['comment_post_id'];
                $show_comment_author = $row['comment_author'];
                $show_comment_email = $row['comment_email'];
                $show_comment_status = $row['comment_status'];
                $show_comment_content = $row['comment_content'];
                $show_comment_date = $row['comment_date'];

                echo"<tr>";
                echo "<td>$show_comment_id</td>";
                echo "<td>$show_comment_post_id</td>";
                echo "<td>$show_comment_author</td>";
                echo "<td>$show_comment_email</td>";
                echo "<td>$show_comment_content</td>";
                echo "<td>$show_comment_status</td>";
                echo "<td>$show_comment_date</td>";

                $query_fetch_post_title = "SELECT * FROM posts WHERE post_id = $show_comment_post_id";
                $connection_post_title = mysqli_query($connection, $query_fetch_post_title);

                while($result = mysqli_fetch_assoc($connection_post_title)){
                    $post_id = $result['post_id'];
                    $post_title = $result['post_title'];
                    echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
                }
                
                echo "<td><a href='admin_comments.php?approve=$show_comment_id'>Approve</a></td>";
                echo "<td><a href='admin_comments.php?unapprove=$show_comment_id'>Unapprove</a></td>";
                echo "<td><a onclick=\"javascript: return confirm('Are you sure you want to delete?') \" href='post_comment.php?delete_comment_post=$show_comment_id'>Delete</a></td>";
                echo"</tr>";
            }
        }
    }
?>

<?php
    function delete_post_comments(){
        global $connection;
        if(isset($_GET['delete_comment_post'])){
            $delete_comment_post_id = $_GET['delete_comment_post'];
            $query_delete_comment_post = "DELETE FROM comments WHERE comment_id = $delete_comment_post_id";
            $connection_delete_comment_post = mysqli_query($connection, $query_delete_comment_post);
            $query = "SELECT * FROM posts post_id = $delete_comment_post_id";
            $connection_query = mysqli_query($connection, $query);
            while($rows = mysqli_fetch_assoc($connection_query)){
                $the_post_id = $rows['post_id'];
            }
            header("location:post_comment.php?id=$the_post_id");
            confirmQuery($connection_delete_comment_post);
        }
    }

?>


<?php
    function redirect($location){
        header("location:$location");
        exit;
    }

    function ifItIsMethod($method=null){
        if($_SERVER['REQUEST_METHOD'] == strtoupper($method)){
            return true;
        }else{
            return false;
        }
    }

    function isLoggedIn(){
        if(isset($_SESSION['user_role'])){
            return true;
        }else{
            return false;
        }
    }

    function checkIfUserIsLoggedInAndRedirect($redirectLocation){
        if(isLoggedIn()){
            redirect($redirectLocation);
        }
    }

    function email_exists($email){
        global $connection;

        $query = "SELECT * FROM users WHERE user_email = '$email'";

        $connection_query = mysqli_query($connection, $query);

        confirmQuery($connection_query);

        if(mysqli_num_rows($connection_query)>0){
            return true;
        }else{
            return false;
        }
    }
?>