<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>User ID</th>
            <th>Username</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Date</th>
            <th colspan="2">Change Role</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        show_users_table();
        ?>
    </tbody>
</table>
<?php
    if(isset($_GET['delete_user'])){
    delete_user();
    }

    if(isset($_GET['change_role_to_admin'])){
    change_role_to_admin();
    }

    if(isset($_GET['change_role_to_subscriber'])){
    change_role_to_subscriber();
    }

?>