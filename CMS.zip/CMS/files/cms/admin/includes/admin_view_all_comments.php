<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Comment ID</th>
            <th>Comment Post ID</th>
            <th>Comment Author</th>
            <th>Comment Email</th>
            <th>Comment Content</th>
            <th>Comment Status</th>
            <th>Comment Date</th>
            <th>In Response to</th>
            <th>Approve</th>
            <th>Unapprove</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        show_comment_table();
        ?>
    </tbody>
</table>
<?php
    if(isset($_GET['delete'])){
    delete_comments();
    }

    if(isset($_GET['approve'])){
    approve_comments();
    }

    if(isset($_GET['unapprove'])){
    unapprove_comments();
    }
?>