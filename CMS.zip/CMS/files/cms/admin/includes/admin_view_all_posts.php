<?php
    if(isset($_POST['checkBoxArray'])){
        foreach($_POST['checkBoxArray'] as $postValueId){
            $bulk_options = $_POST['bulk_options'];
            switch($bulk_options){
                case "published":
                    $query = "UPDATE posts SET post_status = '$bulk_options' WHERE post_id = $postValueId ";
                    $update_to_published_status = mysqli_query($connection, $query);
                    break;

                    case "draft":
                    $query = "UPDATE posts SET post_status = '$bulk_options' WHERE post_id = $postValueId ";
                    $update_to_draft_status = mysqli_query($connection, $query);
                    break;

                    case "delete":
                    $query = "DELETE FROM posts WHERE post_id = $postValueId ";
                    $update_to_delete_status = mysqli_query($connection, $query);
                    break;

                    case "clone":
                    $query = "SELECT * FROM posts WHERE post_id = $postValueId";
                    $fetch_post_data = mysqli_query($connection, $query);
                    while($post_database = mysqli_fetch_assoc($fetch_post_data)){
                        $post_id = $post_database['post_id'];
                        $post_category_id = $post_database['post_category_id'];
                        $post_title = $post_database['post_title'];
                        $post_author = $post_database['post_author'];
                        $post_user = $post_database['post_user'];
                        $post_date = $post_database['post_date'];
                        $post_image = $post_database['post_image'];
                        $post_content = $post_database['post_content'];
                        $post_tags = $post_database['post_tags'];
                        $post_comment_count = $post_database['post_comment_count'];
                        $post_status = $post_database['post_status'];
                        $post_views_count = $post_database['post_views_count'];
                    };

                    $query_clone_post = "INSERT INTO posts(post_category_id, post_title, post_author, post_user, post_date, post_image, post_content, post_tags, post_comment_count, post_status, post_views_count) VALUES($post_category_id, '$post_title', '$post_author', '$post_user', '$post_date', '$post_image', '$post_content', '$post_tags', $post_comment_count, '$post_status', $post_views_count)";

                    $connection_clone_post = mysqli_query($connection, $query_clone_post);
                    confirmQuery($connection_clone_post);
                    break;
            }

        }
    }
?>


<form action="" method="post"> 
    <div id="bulkOptionContainer" class="col-xs-4">
        <select class="form-control" name="bulk_options" id="">
           <option value="">Select Options</option>
           <option value="published">Publish</option> 
           <option value="draft">Draft</option> 
           <option value="delete">Delete</option> 
           <option value="clone">Clone</option> 
        </select>
    </div>
    <div class="col-xs-4">
        <input type="submit" name="submit" value="Apply" class="btn btn-success">
        <a href="admin_posts.php?source=add_post" class="btn btn-primary">Add Post</a>
    </div> 
    <br> 
    <br>  
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th><input type="checkbox" name="selectAllBoxes" id="selectAllBoxes"></th>
                <th>ID</th>
                <th>Category</th>
                <th>Title</th>
                <th>Author</th>
                <!-- <th>User</th> -->
                <th>Date</th>
                <th>Image</th>
                <!--<th>Content</th>-->
                <th>Tags</th>
                <th>Comments</th>
                <th>Status</th>
                <th>View</th>
                <th>Reset Views</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php filling_post_table(); ?>
        </tbody>
    </table>
</form>