<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
    <script src="https://cdn.tiny.cloud/1/ixdpb1e4b3ags2nfcpmu6rprix7q42e1w2t2023wbmcvq4uq/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
    tinymce.init({
      selector: '#mytextarea'
    });
  </script>
</head>
<body>
<?php
   insert_post_into_database();
?>


<form action="" method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="title">Post Title</label>
		<input type="text" name="title" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="post_category">Post Category</label>
		<select class="form-control" name="post_category" id="" required>
			<?php
				$category_selection_query = "SELECT * FROM categories";
    			$send_category_selection_query = mysqli_query($connection, $category_selection_query);

    			while($row = mysqli_fetch_assoc($send_category_selection_query)){
    				$cat_id = $row['cat_id'];
    				$cat_title = $row['cat_title'];
    				echo "<option value='$cat_id'>$cat_title</option>";
    			}
			?>
		</select>
	</div>
	<div class="form-group">
		<label for="post_author">Post Author</label>
		<input type="text" name="post_author" class="form-control" value="<?php echo $_SESSION['firstname'].' '.$_SESSION['lastname']?>" readonly>
	</div>
	<div class="form-group">
		<label for="title">Post Status</label>
		<select name="post_status" id="post_status" class="form-control" required>
			<option value="published">Publish</option>
			<option value="draft">Draft</option>
		</select>
	</div>
	<div class="form-group">
		<label for="post_image">Post Image</label>
		<input type="file" name="image" class="form-control" required>
	</div>	
	<div class="form-group">
		<label for="post_tags">Post Tags</label>
		<input type="text" name="post_tags" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="post_content">Post Content</label>
		<textarea class="form-control" name="post_content" id="mytextarea" cols="30" rows="10" required></textarea>
	</div>
		<div class="form-group">
		<input type="submit" name="create_post" value="Publish Post" class="btn btn-primary">
	</div>	
</form>	
</body>
</html>

