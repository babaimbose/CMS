<?php insert_user_into_database(); ?>

<form action="" method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="user_firstname">First Name</label>
		<input type="text" name="user_firstname" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="user_lastname">Last Name</label>
		<input type="text" name="user_lastname" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="user_role">Role</label>
		<select class="form-control" name="user_role" id="" required>
    				<option value='Admin'>Admin</option>
    				<option value='Subscriber' selected>Subscriber</option>
		</select>
	</div>
	<div class="form-group">
		<label for="user_email">Email</label>
		<input type="email" name="user_email" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="username">Username</label>
		<input type="text" name="username" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="user_password">Password</label>
		<input type="password" name="user_password" class="form-control" required>
	</div>
<!-- 	<div class="form-group">
		<label for="post_image">Post Image</label>
		<input type="file" name="image" class="form-control">
	</div>	 -->
		<div class="form-group">
		<input type="submit" name="create_user" value="Add user" class="btn btn-primary">
	</div>	
</form>