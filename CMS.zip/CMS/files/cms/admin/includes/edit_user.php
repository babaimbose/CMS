<?php 
        if(isset($_GET['user_id'])){
            $edit_user_id = $_GET['user_id'];
            $query_fetch_edit_user_data = "SELECT * FROM users WHERE user_id = $edit_user_id";
            $connection_fetch_edit_user_data = mysqli_query($connection, $query_fetch_edit_user_data);
            confirmQuery($connection);
            }
            while($result = mysqli_fetch_assoc($connection_fetch_edit_user_data)){
                $user_firstname = $result['user_firstname'];
                $user_lastname = $result['user_lastname'];
                $user_username = $result['username'];
                $user_email = $result['user_email'];
                $user_password = $result['user_password'];
                $user_role = $result['user_role'];
        }

?>

<?php 
    if(isset($_POST['update_user'])){
    update_user_data();
    } 
?>

<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="user_firstname">First Name</label>
        <input value="<?php echo $user_firstname; ?>" type="text" name="user_firstname" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="user_lastname">Last Name</label>
        <input value="<?php echo $user_lastname; ?>" type="text" name="user_lastname" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="user_role">Role</label>
        <select class="form-control" name="user_role" id="" required>
            <option value='<?php echo $user_role; ?>'><?php echo $user_role; ?></option>
                    <?php
                        if($user_role == "Admin"){
                        	
                          echo "<option value='Subscriber'>Subscriber</option>";
                        }else{
                            echo "<option value='Admin'>Admin</option>";
                        }
                    ?>
        </select>
    </div>
    <div class="form-group">
        <label for="user_email">Email</label>
        <input value="<?php echo $user_email; ?>" type="email" name="user_email" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="username">Username</label>
        <input value="<?php echo $user_username; ?>" type="text" name="username" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="user_password">Password</label>
        <input value="<?php echo $user_password; ?>" type="password" name="user_password" class="form-control" required>
    </div>
<!--    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image" class="form-control">
    </div>   -->
        <div class="form-group">
        <input type="submit" name="update_user" value="update user" class="btn btn-primary">
    </div>  
</form>
