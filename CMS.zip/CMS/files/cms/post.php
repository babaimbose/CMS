<?php include "includes/header.php"; ?>

    <!-- Navigation -->
<?php include "includes/navigation.php";?>



    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Post Content Column -->
            <div class="col-lg-8">

            <?php
            if(isset($_GET['p_id'])){
                $view_post_id = $_GET['p_id'];
                $query_post_views_count = "UPDATE posts SET post_views_count = post_views_count + 1 WHERE post_id = $view_post_id";
                $connection_post_views_count = mysqli_query($connection, $query_post_views_count);
                confirmQuery($connection_post_views_count);
            }
                ?>
            <?php
                if(isset($_GET['p_id'])){
                $the_post_id = $_GET['p_id'];
                $ind_post_query = "SELECT * FROM posts WHERE post_id = $the_post_id";
                $rows = mysqli_query($connection, $ind_post_query);
                }
                while($row = mysqli_fetch_assoc($rows)){
                    $post_id = $row["post_id"];
                    $post_title = $row["post_title"];
                    $post_author = $row["post_author"];
                    $post_date = $row["post_date"];
                    $post_image = $row["post_image"];
                    $post_content = $row["post_content"];
            ?>


                <!-- First Blog Post -->
                <h2>
                    <a href="#"><?php echo $post_title ?></a>
                </h2>
                <p class="lead">
                    by <a href="author_post.php?author=<?php echo $post_author; ?>"><?php echo $post_author ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span><?php echo "Posted on: " . $post_date ?></p>
                <hr>
                <img class="img-responsive" src="images/<?php echo $post_image; ?>" alt="">
                <hr>
                <p><?php echo $post_content ?></p>

                <hr>
            <?php  
        } 
            ?>

                <!-- Blog Comments -->

                <!-- Comments Form -->

                <?php 



                        if(isset($_POST['submit_comment'])){
                            submit_comment();
                        }

                ?>
                <div class="well">
                    <h4>Leave a Comment:</h4>
                    <form method="post" action="">
                        <div class="form-group">
                            <label for="comment_author">Name</label>
                            <input type="text" class="form-control" name="comment_author" required>
                        </div>
                        <div class="form-group">
                            <label for="comment_email">Email</label>
                            <input type="email" class="form-control" name="comment_email" required>
                        </div>
                        <div class="form-group">
                            <label for="comment_content">Leave a commnet</label>
                            <textarea class="form-control" rows="3" name="comment_content" required></textarea>
                        </div>
                        <input class="btn btn-primary" type="submit" name="submit_comment" value="Submit">
                    </form>
                </div>

                <hr>

                <!-- Posted Comments -->

                <!-- Comment -->
                <?php
                    $query_show_comments_in_posts = "SELECT * FROM comments WHERE comment_post_id = $the_post_id AND comment_status = 'approved' ORDER BY comment_id DESC";
                    $connection_show_comments_in_posts = mysqli_query($connection, $query_show_comments_in_posts);

                    if(!$connection_show_comments_in_posts){
                        die(mysqli_error($connection));
                    }

                    while($result = mysqli_fetch_assoc($connection_show_comments_in_posts)){
                        $comment_author = $result['comment_author'];
                        $comment_date = $result['comment_date'];
                        $comment_content = $result['comment_content'];
                ?>

                    <div class="media">
                        <a class="pull-left" href="#">
                            <img class="media-object" src="http://placehold.it/64x64" alt="">
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading"><?php echo $comment_author; ?>
                                <small><?php echo $comment_date; ?></small>
                            </h4>
                            <?php echo $comment_content; ?>
                        </div>
                    </div>                    

                <?php
                    }
                ?>
            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include "includes/sidebar.php"; ?>

                    </div>
                    <!-- /.row -->
                </div>

            </div>

        </div>
        <!-- /.row -->

        <hr>
        <!-- Footer -->
<?php include "includes/footer.php"; ?>
