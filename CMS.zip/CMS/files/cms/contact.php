<?php  include "includes/header.php"; ?>


    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>

    <?php
    if(isset($_POST['submit'])){
        $to = "babai.m.bose@gmail.com";
        $firstname = mysqli_real_escape_string($connection, trim($_POST['firstname']));
        $lastname = mysqli_real_escape_string($connection, trim($_POST['lastname']));
        $fullname = "$firstname $lastname";
        $header = mysqli_real_escape_string($connection, trim("From: ".$_POST['email']));
        $subject = mysqli_real_escape_string($connection, trim($_POST['subject']));
        $message = wordwrap(mysqli_real_escape_string($connection, trim($_POST['message'])), 70);

        mail($to, $fullname, $subject, $message, $header);
        echo "<p class='text-center'>Email sent successfully</p>";
    }

    ?>
    
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Contact</h1>
                    <form role="form" action="" method="post" autocomplete="off">
                        <div class="form-group">
                            <label for="" class="sr-only">First name</label>
                            <input type="text" name="firstname" class="form-control" placeholder="Enter First name" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="sr-only">Last name</label>
                            <input type="text" name="lastname" class="form-control" placeholder="Enter Last name" required>
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" required>
                        </div>
                        <div class="form-group">
                            <label for="subject" class="sr-only">Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="Enter Subject" required>
                        </div>
                         <div class="form-group">
                            <label for="message" class="sr-only">Message</label>
                            <textarea class="form-control" rows="5" placeholder="Leave a message" name="message" required></textarea>
                        </div>
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Submit">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>

