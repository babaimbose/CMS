<?php session_start();?>

<?php
    $_SESSION['firstname'] = null;
    $_SESSION['lastname'] = null;
    $_SESSION['user_role'] = null;
    $_SESSION['user_email'] = null;
    $_SESSION['username'] = null;

    header("location:../index.php")
?>