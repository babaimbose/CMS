    <?php include "includes/header.php"; ?>
    <!-- Navigation -->
    <?php include "includes/navigation.php";?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                 <h1 class="page-header">
                    CMS Project
                    <small>Learn to code</small>
                </h1>

                <?php
                    if(isset($_GET['p_id'])){
                        $view_post_id = $_GET['p_id'];
                        $query_post_views_count = "UPDATE posts SET post_views_count = post_views_count + 1 WHERE post_id = $view_post_id";
                        $connection_post_views_count = mysqli_query($connection, $query_post_views_count);
                        confirmQuery($connection_post_views_count);
                    }
                ?>

            <?php

            $query_count_posts = "SELECT * FROM posts WHERE post_status = 'published'";
            $connection_count_posts = mysqli_query($connection, $query_count_posts);
            $count_posts = mysqli_num_rows($connection_count_posts);

            $no_of_pages = ceil($count_posts/5);

            if(isset($_GET['page_no'])){
                    $page_no = $_GET['page_no'];
                }else{
                    $page_no = "";
                }

                if($page_no == "" || $page_no == 1){
                    $page_1 = 0;
                    
                }else{
                    $page_1 = ($page_no*5)-5;
                }
            ?>





                <!-- First Blog Post -->

                <?php
                    if(!isset($_SESSION['user_role'])){
                        $query = "SELECT * FROM posts ORDER BY post_id DESC LIMIT $page_1, 5 ";
                        $select_all_from_posts_published = mysqli_query($connection, $query);
                        confirmQuery($select_all_from_posts_published);

                            while($row = mysqli_fetch_assoc($select_all_from_posts_published)){
                            $post_id = $row["post_id"];
                            $post_title = $row["post_title"];
                            $post_author = $row["post_author"];
                            $post_date = $row["post_date"];
                            $post_image = $row["post_image"];
                            $post_status = $row["post_status"];
                            $post_content = substr($row["post_content"],0,250);

                            if($post_status !== "published"){
                                echo "<h1>No Posts Available</h1>";

                            }else{
                            echo "<h2><a href='post.php?p_id=$post_id'>$post_title</a></h2>";
                            echo "<p class='lead'>by <a href='author_post.php?author=$post_author'>$post_author</a></p>";
                            echo "<p><span class='glyphicon glyphicon-time'></span>'Posted on: ' . $post_date </p>";
                            echo "<hr>";
                            echo "<a href='post.php?p_id=$post_id'><img class='img-responsive' src='images/$post_image' alt='image'></a>";
                            echo "<hr>";
                            echo "<p>$post_content</p>";
                            echo "<a class='btn btn-primary' href='post.php?p_id=$post_id'>Read More <span class='glyphicon glyphicon-chevron-right'></span></a>";
                            echo "<hr>";                                
                                }
                            }
                        }else{
                        $query = "SELECT * FROM posts ORDER BY post_id DESC LIMIT $page_1, 5";
                        $select_all_from_posts = mysqli_query($connection, $query);

                        while($row = mysqli_fetch_assoc($select_all_from_posts)){
                        $post_id = $row["post_id"];
                        $post_title = $row["post_title"];
                        $post_author = $row["post_author"];
                        $post_date = $row["post_date"];
                        $post_image = $row["post_image"];
                        $post_status = $row["post_status"];
                        $post_content = substr($row["post_content"],0,250);

                            echo "<h2><a href='post.php?p_id=$post_id'>$post_title</a></h2>";
                            echo "<p class='lead'>by <a href='author_post.php?author=$post_author'>$post_author</a></p>";
                            echo "<p><span class='glyphicon glyphicon-time'></span>'Posted on: ' . $post_date </p>";
                            echo "<hr>";
                            echo "<a href='post.php?p_id=$post_id'><img class='img-responsive' src='images/$post_image' alt='image'></a>";
                            echo "<hr>";
                            echo "<p>$post_content</p>";
                            echo "<a class='btn btn-primary' href='post.php?p_id=$post_id'>Read More <span class='glyphicon glyphicon-chevron-right'></span></a>";
                            echo "<hr>";
                    }
                }
                ?>





                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include "includes/sidebar.php"; ?>

        </div>
        <!-- /.row -->

        <hr>

        <ul class="pager">
            <?php
            for($i=1; $i<=$no_of_pages; $i++){

                if($i == $page_no){
                    echo "<li><a class='active_page' href='index.php?page_no=$i'>$i</a></li>";
                }else{
                    echo "<li><a href='index.php?page_no=$i'>$i</a></li>";
                }
            }



            ?>
        </ul>

        <!-- Footer -->
<?php include "includes/footer.php"; ?>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<script>
    $(document).ready(function(){
        var pusher = new Pusher('179d4307abb58fe3544a', {
            cluster:'ap2'
        });

    var notificationChannel = pusher.subscribe('notifications');

    notificationChannel.bind('new_user', function(notification){
        var message = notification.message;
        alert("New user registration: "+ message);
    });

    });
</script>
