<?php  include "includes/header.php"; ?>
<?php require "vendor/autoload.php" ?>

<?php   

$options = array('cluster' => 'ap2','useTLS' => true);

$pusher = new Pusher\Pusher('179d4307abb58fe3544a', '19fbafb000eaa0724b60', '1211388', $options);

?>


    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>



    <?php
    if(isset($_POST['submit'])){
        $firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
        $lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
        $username = mysqli_real_escape_string($connection, $_POST['username']);
        $email = mysqli_real_escape_string($connection, $_POST['email']);
        $password = mysqli_real_escape_string($connection, $_POST['password']);
        date_default_timezone_set("Asia/Kolkata");
        $time = date("d-m-y h:i:sa");
        $role = "Subscriber";
        $encrypt_password = password_hash($password, PASSWORD_BCRYPT, array("cost"=>12));

/*       $query_signup = "INSERT INTO users(user_firstname, user_lastname, username, user_email, user_password, user_date, user_role) VALUES('$firstname', '$lastname', '$username', '$email', '$password', '$time','Subscriber')";

        $connection_query_signup = mysqli_query($connection, $query_signup);*/



       $query_signup = mysqli_prepare($connection, "INSERT INTO users(user_firstname, user_lastname, username, user_email, user_password, user_date, user_role) VALUES(?,?,?,?,?,?,?)");

        mysqli_stmt_bind_param($query_signup, "sssssss", $firstname, $lastname, $username, $email, $encrypt_password, $time, $role);

        mysqli_stmt_execute($query_signup);

        if(!$query_signup){
            die("Query Failed : ".mysqli_error($connection));
        }

        mysqli_stmt_close($query_signup);

        //pusher
        $data['message'] = $username;
        $pusher->trigger('notifications', 'new_user', $data);
    }

    ?>
    
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Register</h1>
                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">
                        <div class="form-group">
                            <label for="" class="sr-only">First name</label>
                            <input type="text" name="firstname" class="form-control" placeholder="Enter First name" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="sr-only">Last name</label>
                            <input type="text" name="lastname" class="form-control" placeholder="Enter Last name" required>
                        </div>
                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input type="text" name="username" id="username" class="form-control" placeholder="Enter Desired Username" required>
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" required>
                        </div>
                         <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="password" id="key" class="form-control" placeholder="Create Password" required>
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Register">
                        <?php 
                        if(isset($_POST['submit'])){
                            echo "<p class='text-center'>Sign up details submitted successfully</p>";
                        }
                        ?>
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>

