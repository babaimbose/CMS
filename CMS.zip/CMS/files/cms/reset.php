<?php  include "includes/header.php"; ?>
<?php include "admin/functions.php"; ?>

    <!-- Navigation -->
    
<?php  include "includes/navigation.php"; ?>

<?php
    if(!isset($_GET['email']) && !isset($_GET['token'])){
        header("location:index.php");
    }

?>


<!-- Page Content -->
<div class="container">

    <div class="form-gap"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">

                                <h3><i class="fa fa-lock fa-4x"></i></h3>
                                <h2 class="text-center">Reset Password?</h2>
                                <p>You can reset your password here.</p>
                                <div class="panel-body">

                                    <form id="register-form" role="form" autocomplete="off" class="form" method="post">

                                        <div class="form-group">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                                <input id="email" name="new_password" placeholder="Enter new password" class="form-control"  type="password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                                <input id="email" name="confirm_password" placeholder="Confirm password" class="form-control"  type="password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input name="recover-submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
                                        </div>

<?php
    $token = $_GET['token'];
    if($stmt = mysqli_prepare($connection, "SELECT username, user_email, token FROM users WHERE token =?")){
        mysqli_stmt_bind_param($stmt, 's', $token);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $username, $user_email, $token);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);


    if(isset($_POST['recover-submit'])){
        $new_password = mysqli_real_escape_string($connection, trim($_POST['new_password']));
        $confirm_password = mysqli_real_escape_string($connection, trim($_POST['confirm_password']));
        
            if($new_password === $confirm_password){

                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT, array("cost"=>12));
                $stmt2 = mysqli_prepare($connection, "UPDATE users SET token='', user_password='$hashed_password' WHERE user_email = ?");
                mysqli_stmt_bind_param($stmt2, 's', $user_email);
                mysqli_stmt_execute($stmt2);
                if(mysqli_stmt_affected_rows($stmt2)>=1){
                    echo "<div class='form-group'>";
                    echo "<a href='login.php' class='btn btn-lg btn-success'>Pasword Changed : Login</a>";
                    echo "</div>";
                }
                mysqli_stmt_close($stmt2);
            }else{
                echo "Not matched";
            }
        }

}

?>

                                        <input type="hidden" class="hide" name="token" id="token" value="">
                                    </form>

                                </div><!-- Body-->

                                <!--<h2>Please check your email</h2>-->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div> <!-- /.container -->

<div class="container">
    <hr>
 <?php include "includes/footer.php";?>   
</div>

