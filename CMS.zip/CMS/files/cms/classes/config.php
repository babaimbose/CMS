<?php

class Config{
    const SMTP_HOST = 'smtp.mailtrap.io';
    const SMTP_PORT = 2525;
    const SMTP_USER = '9c30edf70fa16d';
    const SMTP_PASSWORD = '53f7ab96cdec71';
}



?>